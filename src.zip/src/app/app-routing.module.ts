import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { AddChallengerComponent } from './add-challenger/add-challenger.component';
import { AuthGuard } from './guards/auth.guard';
import { ChallengerDashboardComponent } from './challenger-dashboard/challenger-dashboard.component';
import { MotivatorDashboardComponent } from './motivator-dashboard/motivator-dashboard.component';
import { SendMotivationComponent } from './motivator-dashboard/send-motivation/send-motivation.component';

import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UpdateChallengerInfoComponent } from './admin-dashboard/update-challenger-info/update-challenger-info.component';
import { ManageUserComponent } from './admin-dashboard/manage-user/manage-user.component';
import { UpdateDietplanComponent } from './admin-dashboard/update-dietplan/update-dietplan.component';
import { GetDietPlanComponent } from './challenger-dashboard/get-diet-plan/get-diet-plan.component';
import { ViewChallengerLogsComponent } from './motivator-dashboard/view-challenger-logs/view-challenger-logs.component';
import { AuthGuardAdmin } from './guards/auth.guard.admin';
import { AuthGuardMotivator } from './guards/auth.guard.motivator';
import { AuthGuardChallenger } from './guards/auth.guard.challenger';
import { UserActivityComponent } from './challenger-dashboard/user-activity/user-activity.component';
import { UserMesurementsComponent } from './challenger-dashboard/user-mesurements/user-mesurements.component';
import { AuthGuardAdminMotivator } from './guards/auth.guards.admin.motivator';
import { CreateGroupComponent } from './admin-dashboard/create-group/create-group.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { AuthGuardMotivatorChallenger } from './guards/auth.guard.motivator.challenger';

const appRoutes: Routes = [
  { path: '', component: LoginComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path : 'challenger-dashboard', component: ChallengerDashboardComponent, canActivate: [AuthGuardChallenger] },
  { path : 'motivator-dashboard',  component: MotivatorDashboardComponent, canActivate: [AuthGuardMotivator] },
  { path : 'admin-dashboard', component : AdminDashboardComponent , canActivate: [AuthGuardAdmin]},
  { path : 'send-motivation', component:SendMotivationComponent, canActivate: [AuthGuardAdminMotivator]},
  { path : 'update-challenger-info/:email/:id', component: UpdateChallengerInfoComponent , canActivate: [AuthGuardAdmin]},
  { path : 'manage-user', component:ManageUserComponent, canActivate: [AuthGuardAdmin]},
  { path: 'register', component: AddChallengerComponent },
  { path: 'upload-diet-plan', component:UpdateDietplanComponent, canActivate: [AuthGuardAdmin]},
  { path: 'get-diet-plan', component:GetDietPlanComponent, canActivate: [AuthGuardMotivatorChallenger]},
  { path: 'view-challenger-log', component:ViewChallengerLogsComponent, canActivate: [AuthGuardAdmin]},
  { path: 'create-groups', component: CreateGroupComponent},
  { path: 'reset-password', component: ResetPasswordComponent},

  { path: 'user-activity', component:UserActivityComponent, canActivate:[AuthGuardMotivatorChallenger]},
  { path: 'user-measurements', component:UserMesurementsComponent, canActivate:[AuthGuardMotivatorChallenger]},
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
  
];

export const routing = RouterModule.forRoot(appRoutes);

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
