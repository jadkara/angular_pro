import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";
import { User } from '../models/user';
import { DailyLog } from '../models/daily-log';
import { MonthlyMeasurement } from '../models/monthly-measurement';
import { Challenger } from '../models/challenger';
import { Batch } from '../models/batch';
import { GroupEntity } from '../models/group';
import { DietPlan } from '../models/diet-plan';

@Injectable({
  providedIn: 'root'
})
export class DietManagementService {

  constructor(private http: HttpClient) { }

  private baseUrl = "http://localhost:8080/api/v1/"; // URL to web api

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'my-auth-token'
    })
  };

  httpOptionsFor = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'my-auth-token'
    })
  };

  httpOptionsFormData = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token',
    })
  };

  saveChallenger(challenger: object): Observable<Object> {
    return this.http.post(this.baseUrl + 'save-challenger', challenger);
  }

  saveUser(user: object): Observable<Object> {
    return this.http.post(this.baseUrl + 'save-user', user);
  }

  login(username: String, userpassword: String): Observable<Object> {
    return this.http.post(this.baseUrl + 'login', {
      email: username,
      password: userpassword
    }, this.httpOptions);
  }

  addUserLog(dailyLog: DailyLog): Observable<Object> {
    return this.http.post(this.baseUrl + 'save-daily-log', dailyLog);
  }

  saveMonthlyMeasurement(monthlyLog: MonthlyMeasurement): Observable<Object> {
    return this.http.post(this.baseUrl + 'save-monthly-measurementlog', monthlyLog);
  }

  getChallengerDailyLogs(): Observable<Object> {
    return this.http.get(this.baseUrl + 'get-all-daily-log');
  }

  getChallengerMonthlyLogs(): Observable<Object> {
    return this.http.get(this.baseUrl + 'get-monthly-measurement-log');
  }

  getNonadminUsers(): Observable<Object> {
    return this.http.get(this.baseUrl + 'get-other-users');
  }

  getChallengers(): Observable<Object> {
    return this.http.get(this.baseUrl + 'get-challengers');
  }

  updateChallengerStatus(challenger: Challenger): Observable<Object> {
    return this.http.put(this.baseUrl + 'update-challenger-status', challenger);
  }


  updateChallenger(challenger: Challenger): Observable<Object> {
    return this.http.put(this.baseUrl + 'update-challenger', challenger);
  }

  updateUser(user: User): Observable<Object> {
    return this.http.put(this.baseUrl + 'update-user', user);
  }

  sendMail(email: String, fullname: String, status: String, rejectionReason: String): Observable<Object> {
    return this.http.post(this.baseUrl + 'send-email', {
      fullname: fullname,
      email: email,
      status: status,
      rejectionReason: rejectionReason
    }, this.httpOptions);
  }


  getChallengerByEmail(email: String): Observable<Object> {
    return this.http.post<Challenger>(this.baseUrl + 'get-challenger-by-email', {
      email: email
    }, this.httpOptions);
  }

  getBatches(): Observable<Object> {
    return this.http.get<Batch>(this.baseUrl + 'get-batches');
  }

  getGroupsByBatch(batchId: String): Observable<Object> {
    return this.http.post<GroupEntity[]>(this.baseUrl + 'get-groups', { batchId: batchId }, this.httpOptions);
  }

  // getGroups(batchId: String): Observable<Object> {
  //   return this.http.post<GroupEntity[]>(this.baseUrl + 'get-groups', { batchId: batchId }, this.httpOptions);
  // }

  deleteUser(user: object): Observable<Object> {
    return this.http.post(this.baseUrl + 'delete-user',
      { user: user }, this.httpOptions);
  }

  saveDietPlan(batchId: String, plan: File): Observable<Object> {
    const fb = new FormData();
    fb.append('file', plan);
    fb.append('batchid', "" + batchId);
    return this.http.post(this.baseUrl + 'save-diet-plan', fb);
  }

  downloadDietPlan(batchId: String): Observable<Object> {
    return this.http.post(this.baseUrl + 'get-diet-plan-by-batch', { batchId: batchId });
  }

  sendMotivation(senders: String[], message: String[]): Observable<Object> {
    console.log("senders=" + senders);
    return this.http.post(this.baseUrl + 'send-motivation', {
      senders: senders,
      message: message
    }, this.httpOptions);
  }

  sendMotivationWithAttachment(file: File, senders: String[], message: String, filename: String): Observable<Object> {
    const fb = new FormData();
    fb.append('file', file);
    fb.append('senders', "" + senders.toString());
    fb.append('message', "" + message.toString());
    fb.append('filename', "" + filename);
    return this.http.post(this.baseUrl + 'send-motivation-attachment', fb);
  }

  saveGroup(group: object): Observable<Object> {
    return this.http.post(this.baseUrl + 'save-group', group);
  }

}
