import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

import { User } from '../models/user';
import { DietManagementService } from './diet-management.service';
import { AlertService } from './alert.service';
// import { AppComponent } from '../app.component';

@Injectable({ providedIn: 'root' })
export class AuthenticationService implements OnInit, OnDestroy{
    public currentUserSubject: BehaviorSubject<User>;
    public loggedUser: User=new User();
    public currentUser: Observable<User>;
    loading = false;

    constructor(private http: HttpClient,private router: Router,
        private dietService:DietManagementService,
        private alertService: AlertService
        // , private appComponent:AppComponent
        ) {
            this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
            this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        // console.log('currentUser.name='+this.currentUser.fullName);
        // return this.currentUser.value;
        return this.currentUserSubject.value;
    }
    public get loggedUserValue(): User {
        // console.log('currentUser.name='+this.currentUser.fullName);
        // return this.currentUser.value;
        return this.loggedUser;
    }

    public get loadingValue():boolean {
        return this.loading;
    }

    login(username: string, password: string) {
        return this.dietService.login(username, password).subscribe((data: User)=> {
			if(data === null){
                console.log("Invalid credentials!");
                this.alertService.error('Username or password is incorrect');
                
			}else{
				 console.log(data.id+" Logged in Successfully with role : "+data.userType);
                console.log('data.name='+data.fullName);
                localStorage.setItem('currentUser', JSON.stringify(data));
                this.currentUserSubject.next(data);
                this.loggedUser = data;
                this.loading = false;
                this.loadDashboard(data);
                // this.router.navigate(['/home']);
			}
        }, error =>{
            this.alertService.error(error);
        });

    }

    loadDashboard(user : User){
        console.log('user.userType='+user.userType);
        if(user.userType === 'CHALLENGER'){
            this.router.navigate(['challenger-dashboard']);
            // this.router.navigate(['motivator-dashboard']);
        }else if(user.userType === 'ADMIN'){
            this.router.navigate(['admin-dashboard']);
        }else {
            this.router.navigate(['motivator-dashboard']);
        }
      }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        // this.currentUserSubject.unsubscribe();
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        this.currentUser = null;
        // unsubscribe to ensure no memory leaks
        // this.currentUserSubject.unsubscribe();
    }
}