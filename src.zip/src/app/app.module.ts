import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';
import { routing } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// used to create fake backend
import { AlertComponent } from './alert/alert.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AddChallengerComponent } from './add-challenger/add-challenger.component';

import { JwtInterceptor } from './helpers/jwt.interceptor';
import { ErrorInterceptor } from './helpers/error.interceptor';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { ChallengerDashboardComponent } from './challenger-dashboard/challenger-dashboard.component';
import { UserActivityComponent } from './challenger-dashboard/user-activity/user-activity.component';
import { UserMesurementsComponent } from './challenger-dashboard/user-mesurements/user-mesurements.component';
import { MotivatorDashboardComponent } from './motivator-dashboard/motivator-dashboard.component';
import { ViewChallengerLogsComponent } from './motivator-dashboard/view-challenger-logs/view-challenger-logs.component';
import { SendMotivationComponent } from './motivator-dashboard/send-motivation/send-motivation.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UpdateChallengerInfoComponent } from './admin-dashboard/update-challenger-info/update-challenger-info.component';
import { ManageUserComponent } from './admin-dashboard/manage-user/manage-user.component';
import { UpdateDietplanComponent } from './admin-dashboard/update-dietplan/update-dietplan.component';
import { GetDietPlanComponent } from './challenger-dashboard/get-diet-plan/get-diet-plan.component';
import { CreateGroupComponent } from './admin-dashboard/create-group/create-group.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AlertComponent,
    AddChallengerComponent,
    ChallengerDashboardComponent,
    UserActivityComponent,
    UserMesurementsComponent,
    MotivatorDashboardComponent,
    ViewChallengerLogsComponent,
    SendMotivationComponent,
    AdminDashboardComponent,
    UpdateChallengerInfoComponent,
    ManageUserComponent,
    UpdateDietplanComponent,
    GetDietPlanComponent,
    CreateGroupComponent,
    ResetPasswordComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    routing,
    ReactiveFormsModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatDatepickerModule,
    MatInputModule,
    MatIconModule,
    MatMenuModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatListModule,
    MatTabsModule,
    MatSidenavModule,
    MatDividerModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
