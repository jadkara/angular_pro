import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMesurementsComponent } from './user-mesurements.component';

describe('UserMesurementsComponent', () => {
  let component: UserMesurementsComponent;
  let fixture: ComponentFixture<UserMesurementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserMesurementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserMesurementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
