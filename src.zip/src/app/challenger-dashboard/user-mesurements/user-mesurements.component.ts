import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { DietManagementService } from 'src/app/services/diet-management.service';
import { MonthlyMeasurement } from 'src/app/models/monthly-measurement';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { User } from 'src/app/models/user';


// Depending on whether rollup is used, moment needs to be imported differently.
// Since Moment.js doesn't have a default export, we normally need to import using the `* as`
// syntax. However, rollup creates a synthetic default module and we thus need to import it using
// the `default as` syntax.
import * as _moment from 'moment/moment.js';
// tslint:disable-next-line:no-duplicate-imports
// import {default as _rollupMoment} from 'moment/moment.js';

const moment = _moment;

// See the Moment.js docs for the meaning of these formats:
// https://momentjs.com/docs/#/displaying/format/
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-user-mesurements',
  templateUrl: './user-mesurements.component.html',
  styleUrls: ['./user-mesurements.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS] },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})
export class UserMesurementsComponent implements OnInit {

  dateValue = new FormControl(moment());

  private monthlyMeasurement: MonthlyMeasurement = new MonthlyMeasurement();
  currentUser: User;
  currentUserSubscription: Subscription;


  monthlymeasurementform = new FormGroup({
    weight: new FormControl('', []),
    height: new FormControl('', []),
    chest: new FormControl('', []),
    waist: new FormControl('', []),
    shoulders: new FormControl('', []),
    biceps: new FormControl('', []),
    forearm: new FormControl('', []),
    legs: new FormControl('', []),
    thighs: new FormControl('', [])
  });

  constructor(private dietService: DietManagementService,
    private authenticationService: AuthenticationService, private _router: Router) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
    });
  }

  ngOnInit(): void {
  }

  submitForm() {
    this.monthlyMeasurement.userId = this.currentUser.id;

    console.log("enter monthly Log : userid :: " + this.monthlyMeasurement.userId);
    console.log('this.dateValue.value=' + this.dateValue);
    this.monthlyMeasurement.date = this.dateValue.value;
    console.log("submitLog : date :: " + this.monthlyMeasurement.date);
    this.monthlyMeasurement.weight = this.monthlymeasurementform.get('weight').value;
    this.monthlyMeasurement.height = this.monthlymeasurementform.get('height').value;
    this.monthlyMeasurement.chest = this.monthlymeasurementform.get('chest').value;
    this.monthlyMeasurement.waist = this.monthlymeasurementform.get('waist').value;
    this.monthlyMeasurement.shoulders = this.monthlymeasurementform.get('shoulders').value;
    this.monthlyMeasurement.biceps = this.monthlymeasurementform.get('biceps').value;
    this.monthlyMeasurement.forearm = this.monthlymeasurementform.get('forearm').value;
    this.monthlyMeasurement.legs = this.monthlymeasurementform.get('legs').value;
    this.monthlyMeasurement.thighs = this.monthlymeasurementform.get('thighs').value;
    this.saveMonthlyMeasurement();
  }


  saveMonthlyMeasurement() {
    this.dietService.saveMonthlyMeasurement(this.monthlyMeasurement)
      .pipe(map((data: MonthlyMeasurement) => {
        if (data != null && data.userId != null) {
          console.log("Monthly measurement logs added for : " + data.userId + "!");
          this._router.navigate(['challenger-dashboard']);
        }
      }))
      .pipe(catchError((error: any) => {
        if (error.status < 400 || error.status === 500) {
          return Observable.throw(new Error(error.status));
        }
      }))
      .subscribe(data => console.log(data), error => console.log(error));
  }



}
