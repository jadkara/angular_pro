import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetDietPlanComponent } from './get-diet-plan.component';

describe('GetDietPlanComponent', () => {
  let component: GetDietPlanComponent;
  let fixture: ComponentFixture<GetDietPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetDietPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetDietPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
