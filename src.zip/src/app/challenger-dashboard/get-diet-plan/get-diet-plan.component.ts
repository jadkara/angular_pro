import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { DietPlan } from 'src/app/models/diet-plan';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-get-diet-plan',
  templateUrl: './get-diet-plan.component.html',
  styleUrls: ['./get-diet-plan.component.css']
})
export class GetDietPlanComponent implements OnInit {

  currentUser: User;
  currentUserSubscription: Subscription;
  users: User[] = [];

  constructor(private authenticationService: AuthenticationService, private dietService: DietManagementService) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
    });
  }
  dietPlan: DietPlan = new DietPlan();

  ngOnInit(): void {
  }

  uploadPaths = [];

  submit() {
    let batchId: String = this.currentUser.batchId;
    console.log("batchId=" + this.currentUser.batchId);
    console.log("fullName=" + this.currentUser.fullName);
    this.dietService.downloadDietPlan(batchId)
      .pipe(map((res: DietPlan) => {
        if (res != null && res.batchId != null) {
          this.dietPlan = res;
          console.log("Download successfully");
          var a = document.createElement("a");
          var file = new Blob([res.dietPlanDetails]);
          a.href = URL.createObjectURL(file);
          a.download = res.fileName;
          a.click();
        }
      }))
      .pipe(catchError((error: any) => {
        if (error.status < 400 || error.status === 500) {
          return Observable.throw(new Error(error.status));
        }
      }))
      .subscribe(res => console.log(res), error => console.log(error));
  }
}
