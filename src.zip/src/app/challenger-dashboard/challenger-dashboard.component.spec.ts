import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChallengerDashboardComponent } from './challenger-dashboard.component';

describe('ChallengerDashboardComponent', () => {
  let component: ChallengerDashboardComponent;
  let fixture: ComponentFixture<ChallengerDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChallengerDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengerDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
