import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { DietManagementService } from 'src/app/services/diet-management.service';
import { DailyLog } from 'src/app/models/daily-log';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
	selector: 'app-user-activity',
	templateUrl: './user-activity.component.html',
	styleUrls: ['./user-activity.component.css']
})
export class UserActivityComponent implements OnInit {

	currentUser: User;
	currentUserSubscription: Subscription;
	users: User[] = [];

	constructor(private dietService: DietManagementService, private authenticationService: AuthenticationService, private _router: Router) {
		this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
			this.currentUser = user;
		});
	}
	submitted = false;
	dailyLog: DailyLog = new DailyLog();

	ngOnInit() {
		this.submitted = false;
	}
	useractivityform = new FormGroup({
		activityDate: new FormControl('', [Validators.required]),
		breakfast: new FormControl('', []),
		lunch: new FormControl('', []),
		dinner: new FormControl('', []),
		fruits: new FormControl('', []),
		vegetables: new FormControl('', []),
		workouts: new FormControl('', [])
	});

	enterLog() {
		this.dailyLog.userId = this.currentUser.id;
		console.log("enterLog : userid :: " + this.dailyLog.userId);
		this.dailyLog.activityDate = this.useractivityform.get('activityDate').value;
		this.dailyLog.breakfast = this.useractivityform.get('breakfast').value;
		this.dailyLog.lunch = this.useractivityform.get('lunch').value;
		this.dailyLog.dinner = this.useractivityform.get('dinner').value;
		this.dailyLog.fruits = this.useractivityform.get('fruits').value;
		this.dailyLog.vegetables = this.useractivityform.get('vegetables').value;
		this.dailyLog.workouts = this.useractivityform.get('workouts').value;
		this.submitted = true;

		this.dietService.addUserLog(this.dailyLog)
			.pipe(map((res: DailyLog) => {
				if (res != null && res.userId != null) {
					console.log("Daily user logs added for : " + res.userId + "!");
					this._router.navigate(['challenger-dashboard']);
				}
			}))
			.pipe(catchError((error: any) => {
				if (error.status < 400 || error.status === 500) {
					return Observable.throw(new Error(error.status));
				}
			}))
			.subscribe(res => console.log(res), error => console.log(error));
	}

}