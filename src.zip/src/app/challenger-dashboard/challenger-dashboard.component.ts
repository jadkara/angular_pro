import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-challenger-dashboard',
  templateUrl: './challenger-dashboard.component.html',
  styleUrls: ['./challenger-dashboard.component.css']
})
export class ChallengerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
