import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { AuthenticationService } from './services/authentication.service';
import { User } from './models/user';

@Component({
    selector: 'app',
    templateUrl: './app.component.html'
})
export class AppComponent {
    currentUser: User;
    adminUserType: boolean = false;
    motivatorUserType: boolean = false;
    challengerUserType: boolean = false;
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService) {
        this.authenticationService.currentUser.subscribe(
            x => {
                this.currentUser = x;
                console.log('selected the user');
                if (this.currentUser) {
                    this.updateUserStatus();
                }

            }
        );
    }

    updateUserStatus() {
        if (this.currentUser.userType === 'ADMIN') {
            this.adminUserType = true;
            this.motivatorUserType = true;
        } else if (this.currentUser.userType === "MOTIVATOR") {
            this.challengerUserType = true;
            this.motivatorUserType = true;
        } else {
            this.challengerUserType = true;
        }
    }

    logout() {
        this.adminUserType = false;
        this.motivatorUserType = false;
        this.challengerUserType = false;
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }
}