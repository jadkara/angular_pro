import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotivatorDashboardComponent } from './motivator-dashboard.component';

describe('MotivatorDashboardComponent', () => {
  let component: MotivatorDashboardComponent;
  let fixture: ComponentFixture<MotivatorDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotivatorDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotivatorDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
