import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DailyLog } from 'src/app/models/daily-log';
import { MonthlyMeasurement } from 'src/app/models/monthly-measurement';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-view-challenger-logs',
  templateUrl: './view-challenger-logs.component.html'


})
export class ViewChallengerLogsComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatTableDataSource, { static: true }) dataSourceDaily: MatTableDataSource<DailyLog> | null;
  @ViewChild(MatTableDataSource, { static: true }) dataSourceMonthly: MatTableDataSource<MonthlyMeasurement> | null;
  displayedWeeklyColumns = ['userId', 'activityDate', 'breakfast', 'lunch', 'dinner', 'fruits', 'vegetables', 'workouts'];
  displayedMonthlyColumns = ['userId', 'date', 'weight', 'height', 'chest', 'waist', 'shoulders', 'biceps', 'forearm', 'legs', 'thighs'];
  selectedLog: String = '';
  isDaily: boolean = false;

  viewChallengerLogsForm = new FormGroup({
    logType: new FormControl('', [Validators.required]),
    thighs: new FormControl('', [])
  });

  constructor(private dietService: DietManagementService) { }

  ngOnInit(): void {
    this.selectedLog = '';
    this.isDaily = false;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    if (this.viewChallengerLogsForm.get('logType').value == 'daily') {
      this.dataSourceDaily.filter = filterValue;
    } else if (this.viewChallengerLogsForm.get('logType').value == 'monthly') {
      this.dataSourceMonthly.filter = filterValue;
    }
  }

  selectedLogType(event) {
    this.selectedLog = this.viewChallengerLogsForm.get('logType').value;
    if (this.selectedLog == 'daily') {
      this.loadDailyLogs();
      this.isDaily = true;
    } else {
      this.loadMonthlyLogs();
      this.isDaily = false;
    }
  }

  loadDailyLogs() {
    this.dietService.getChallengerDailyLogs().subscribe((data: DailyLog[]) => {
      if (data === null) {
        console.log("No daily logs loaded!");
      } else {
        console.log("daily logs loaded Successfully " + data.length);
        this.dataSourceDaily = new MatTableDataSource(data);
        this.dataSourceDaily.paginator = this.paginator;
        this.dataSourceDaily.sort = this.sort;
      }
    }, error => console.log(error));
  }

  loadMonthlyLogs() {
    this.dietService.getChallengerMonthlyLogs().subscribe((data: MonthlyMeasurement[]) => {
      if (data === null) {
        console.log("No monthly logs loaded!");
      } else {
        console.log("monthly logs loaded Successfully " + data.length);
        this.dataSourceMonthly = new MatTableDataSource(data);
        this.dataSourceMonthly.paginator = this.paginator;
        this.dataSourceMonthly.sort = this.sort;
      }
    }, error => console.log(error));
  }

}
