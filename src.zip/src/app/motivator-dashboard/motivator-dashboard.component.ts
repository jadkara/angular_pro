import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motivator-dashboard',
  templateUrl: './motivator-dashboard.component.html',
  styleUrls: ['./motivator-dashboard.component.css']
})
export class MotivatorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
