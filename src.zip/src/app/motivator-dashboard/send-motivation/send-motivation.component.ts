import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Batch } from 'src/app/models/batch';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-send-motivation',
  templateUrl: './send-motivation.component.html',
  styleUrls: ['./send-motivation.component.css']
})
export class SendMotivationComponent implements OnInit, OnDestroy {

  currentUser: User;
  currentUserSubscription: Subscription;
  users: User[] = [];

  public receivedMessages: string[] = [];

  messageForm = new FormGroup({
    receivers: new FormControl('', [Validators.required]),
    message: new FormControl('', [Validators.required]),
    file: new FormControl('', [Validators.required])
  });

  constructor(private dietService: DietManagementService, private authenticationService: AuthenticationService) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
    });
  }

  ngOnInit(): void {
    this.loadNonAdminUsers();
  }

  ngOnDestroy() {
    this.currentUserSubscription.unsubscribe();
  }

  loadNonAdminUsers() {
    this.dietService.getNonadminUsers().subscribe((data: User[]) => {
      if (data === null) {
        console.log("No users available !");
      } else {
        console.log("Users loaded Successfully " + data.length);
        this.users = data;
      }
    }, error => console.log(error));
  }

  changedValue(event) {
    if (event.checked) {
      console.log("Selected by admin : " + event.source.value);
      this.receivedMessages.push(event.source.value);
    } else {
      console.log("Deselect by admin : " + event.source.value);
      const index = this.receivedMessages.indexOf(event.source.value, 0);
      if (index > -1) {
        this.receivedMessages.splice(index, 1);
      }

    }
  }
  attachmentFile: File;
  isFileSelected: boolean = false;
  upload(files: File[]) {
    this.attachmentFile = files[0];
    this.isFileSelected = true;
  }

  sendEmail() {
    let message = this.messageForm.get('message').value;
    let messageArray: String[] = [];
    messageArray.push(message);
    if (!this.isFileSelected) {
      console.log("File not selected");

      this.dietService.sendMotivation(this.receivedMessages, messageArray)
        .subscribe(data => console.log(data), error => console.log(error));

    } else {
      this.dietService.sendMotivationWithAttachment(this.attachmentFile, this.receivedMessages, message, this.attachmentFile.name)
        .subscribe(data => console.log(data), error => console.log(error));
    }
  }
}
