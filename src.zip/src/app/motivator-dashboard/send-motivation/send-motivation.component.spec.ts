import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendMotivationComponent } from './send-motivation.component';

describe('SendMotivationComponent', () => {
  let component: SendMotivationComponent;
  let fixture: ComponentFixture<SendMotivationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendMotivationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendMotivationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
