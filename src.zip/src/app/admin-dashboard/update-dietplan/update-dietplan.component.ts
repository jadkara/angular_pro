import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Batch } from 'src/app/models/batch';
import { DietPlan } from 'src/app/models/diet-plan';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-update-dietplan',
  templateUrl: './update-dietplan.component.html',
  styleUrls: ['./update-dietplan.component.css']
})
export class UpdateDietplanComponent implements OnInit {

  batches: Batch[] = [];
  batchId: String;
  planFile: File;

  uploadDietPlanForm = new FormGroup({
    batch: new FormControl('', [Validators.required]),
    plan: new FormControl('', [Validators.required]),
  });

  constructor(private dietService: DietManagementService) {
    this.loadBatches();
  }
  loadBatches() {
    this.dietService.getBatches().subscribe((data: Batch[]) => {
      if (data === null) {
        console.log("No Batch available");
      } else {
        console.log("Batch loaded successfully");
        this.batches = data;
      }
    }, error => console.log(error));
  }

  upload(files: File[]) {
    console.log("Batch : " + this.uploadDietPlanForm.get('batch').value);
    console.log("Plan : " + this.uploadDietPlanForm.get('plan').value);
    this.batchId = this.uploadDietPlanForm.get('batch').value;
    this.planFile = files[0];// this.uploadDietPlanForm.get('plan').value;
    console.log('planFile--:' + this.planFile);
  }

  submit() {

    this.dietService.saveDietPlan(this.batchId, this.planFile)
      .subscribe((res: DietPlan) => {
        if (res === null) {
          console.log("Diet plan not added!");
        } else {
          console.log("Diet plan added!" + res);
        }
      }, error => console.log(error));
  }

  // this.dietService.saveDietPlan(this.batchId, this.planFile)
  //   .subscribe((res: DietPlan) => {
  //     if (res === null) {
  //       console.log("Diet plan not added!");
  //     } else {
  //       console.log("Diet plan added!" + res);
  //     }
  //   }, error => console.log(error));
  // }

  ngOnInit(): void {
  }

}
