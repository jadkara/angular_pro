import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Batch } from 'src/app/models/batch';
import { GroupEntity } from 'src/app/models/group';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.css']
})
export class CreateGroupComponent {
  currentUser: User;
  batches: Batch[] = [];

  groups: GroupEntity[] = [];


  groupForm = new FormGroup({
    batch: new FormControl('', [Validators.required]),
    groupname: new FormControl('', [Validators.required])
  });

  constructor(private dietService: DietManagementService, private authenticationService: AuthenticationService) {
    this.loadSelectedBatchGroups('1');
    this.loadBatches();
  }

  loadBatches() {
    this.dietService.getBatches().subscribe((data: Batch[]) => {
      if (data === null) {
        console.log("No Batch available");
      } else {
        console.log("Batch loaded successfully");
        this.batches = data;
      }
    }, error => console.log(error));
  }

  loadSelectedBatchGroups(batchId: String) {
    console.log('batchId=' + batchId);
    this.dietService.getGroupsByBatch(batchId).subscribe((data: GroupEntity[]) => {
      if (data === null) {
        console.log("No Group loaded!");
      } else {
        console.log("Groups loaded Successfully " + data);
        this.groups = data;
      }
    }, error => console.log(error));


  }

  createGroup() {
    let batchId = this.groupForm.get('batch').value;
    let groupname = this.groupForm.get('groupname').value;
    console.log("batchId=" + batchId);

    let group: GroupEntity = new GroupEntity();
    group.batchId = batchId;
    group.groupName = groupname;

    this.dietService.saveGroup(group)
      .pipe(map((res: GroupEntity) => {
        if (res != null) {
          console.log(res.groupName + "  saved uccessfully!")
        }
      }))
      .pipe(catchError((error: any) => {
        if (error.status < 400 || error.status === 500) {
          return Observable.throw(new Error(error.status));
        }
      }))
      .subscribe(res => console.log(res), error => console.log(error));
    console.log('batchId=' + batchId);
    this.loadSelectedBatchGroups(batchId);
  }
}
