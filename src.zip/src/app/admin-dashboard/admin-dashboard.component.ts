import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Challenger } from '../models/challenger';
import { User } from '../models/user';
import { DietManagementService } from '../services/diet-management.service';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  displayedColumns = ['fullName', 'age', 'gender', 'state', 'country', 'bmi', 'reason', 'medicalCondition', 'dietRestriction',
    'dietType', 'pregnancyStatus', 'currentStatus', 'referredCode', 'rejectionReason', 'status'];
  user: User = new User();
  challengers: Challenger[] = [];
  isRejected: boolean = false;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatTableDataSource, { static: true }) dataSource: MatTableDataSource<Challenger> | null;

  challengerStatusForm = new FormGroup({
    rejectionReason: new FormControl('', [Validators.required])
  });

  constructor(private dietService: DietManagementService) {
    this.loadAllChallenger();
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  loadAllChallenger() {
    this.dietService.getChallengers().subscribe((data: Challenger[]) => {
      if (data === null) {
        console.log("No users available !");
      } else {
        console.log("Users loaded Successfully " + data.length);
        this.challengers = data;
        for (var ch of data) {
          console.log('email=' + ch.email);
          console.log('age=' + ch.age);
        }
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    }, error => console.log(error));
  }

  approved(approvedChallenger: Challenger) {
    console.log('Selected approvedChallenger email===' + approvedChallenger.email);
    this.updateChallengerStatus(approvedChallenger, 'Approved');
  }
  rejected(rejectedChallenger: Challenger) {
    //Update challenger with status
    this.isRejected = true;
    rejectedChallenger.rejectionReason = this.challengerStatusForm.get('rejectionReason').value;
    this.updateChallengerStatus(rejectedChallenger, 'Rejected');
    console.log("Rejection reason - " + rejectedChallenger.rejectionReason);
  }

  updateChallengerStatus(updateChallenger: Challenger, update: String) {
    updateChallenger.status = update;
    this.dietService.updateChallengerStatus(updateChallenger)
      .pipe(map((res: Challenger) => {
        if (res != null) {
          console.log("Sending mail to user - " + res.email);
          if (res.status != null && res.status != '')
            this.sendMail(res);
        }
      }))
      .pipe(catchError((error: any) => {
        if (error.status < 400 || error.status === 500) {
          return Observable.throw(new Error(error.status));
        }
      }))
      .subscribe(data => console.log(data), error => console.log(error));
  }

  sendMail(challenger: Challenger) {
    this.dietService.sendMail(challenger.email, challenger.fullName, challenger.status, challenger.rejectionReason)
      .subscribe(data => console.log(data), error => console.log(error));
  }

  ngOnInit(): void {
  }

}
