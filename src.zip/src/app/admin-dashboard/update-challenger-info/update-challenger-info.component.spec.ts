import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateChallengerInfoComponent } from './update-challenger-info.component';

describe('UpdateChallengerInfoComponent', () => {
  let component: UpdateChallengerInfoComponent;
  let fixture: ComponentFixture<UpdateChallengerInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateChallengerInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateChallengerInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
