import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Challenger } from 'src/app/models/challenger';
import { User } from 'src/app/models/user';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
	selector: 'app-update-challenger-info',
	templateUrl: './update-challenger-info.component.html',
	styleUrls: ['./update-challenger-info.component.css']
})
export class UpdateChallengerInfoComponent implements OnInit {

	submitted = false;
	challenger: Challenger = new Challenger();
	updatedUser: User = new User();
	emailid: String;
	userid: String;
	challengers: Observable<Challenger>;
	challengerEditForm: FormGroup;

	constructor(private dietService: DietManagementService, private router: Router, private route: ActivatedRoute
	) {
		this.submitted = false;
	}

	ngOnInit(): void {

		this.submitted = false;
		this.challengerEditForm = new FormGroup({
			fullName: new FormControl('', [Validators.required]),
			age: new FormControl('', [Validators.required]),
			gender: new FormControl('', [Validators.required]),
			mobile: new FormControl('', [Validators.required]),//Validators.maxLength(10),Validators.maxLength(10),Validators.pattern('(7|8|9)\d{9}')
			email: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]),
			address: new FormControl('', [Validators.maxLength(150)]),
			city: new FormControl('', []),
			state: new FormControl('', [Validators.required]),
			country: new FormControl('', [Validators.required]),
			pincode: new FormControl('', [Validators.required]),
			height: new FormControl('', []),//Validators.pattern('\d{6}')
			weight: new FormControl('', []),
			reason: new FormControl('', []),
			medicalCondition: new FormControl('', []),
			dietRestriction: new FormControl('', []),
			dietType: new FormControl('', []),
			pregnancyStatus: new FormControl('', []),
		});

		let id = this.route.snapshot.paramMap.get("id");
		console.log('id=' + id);
		this.route.paramMap.subscribe(params => {


			this.emailid = params.get('email');
			console.log('email==' + this.emailid);

			this.userid = params.get('id');
			this.loadChallenger();
		});
	}

	loadChallenger() {
		this.challengers = this.dietService.getChallengerByEmail(this.emailid)
			.pipe(
				tap((data: Challenger) => {
					console.log("inside tap");
					console.log('challenger fullname=' + data.fullName);
					this.challengerEditForm.patchValue(data);
					this.challenger = data;
				})
			)
			.pipe(catchError((error: any) => {
				if (error.status < 400 || error.status === 500) {
					return Observable.throw(new Error(error.status));
				}
			}));


		this.challengers.subscribe(data => {
			if (data != null) {
				this.challenger = data;
				console.log("loadChallenger : user " + this.challenger.fullName + " details loaded!");
			}
		}, error => console.log(error));
	}

	onsubmit() {
		this.challenger.fullName = this.challengerEditForm.get('fullName').value;
		this.challenger.age = this.challengerEditForm.get('age').value;
		this.challenger.gender = this.challengerEditForm.get('gender').value;;
		this.challenger.mobile = this.challengerEditForm.get('mobile').value;
		this.challenger.email = this.challengerEditForm.get('email').value;
		this.challenger.address = this.challengerEditForm.get('address').value;
		this.challenger.city = this.challengerEditForm.get('city').value;
		this.challenger.state = this.challengerEditForm.get('state').value;
		this.challenger.country = this.challengerEditForm.get('country').value;
		this.challenger.pincode = this.challengerEditForm.get('pincode').value;
		this.challenger.height = this.challengerEditForm.get('height').value;
		this.challenger.weight = this.challengerEditForm.get('weight').value;
		this.challenger.reason = this.challengerEditForm.get('reason').value;
		this.challenger.medicalCondition = this.challengerEditForm.get('medicalCondition').value;
		this.challenger.dietRestriction = this.challengerEditForm.get('dietRestriction').value;
		this.challenger.dietType = this.challengerEditForm.get('dietType').value;
		this.challenger.pregnancyStatus = this.challengerEditForm.get('pregnancyStatus').value;
		this.submitted = true;
		this.updateUsers();
	}

	updateUsers() {
		let userValue: User = new User();
		userValue.id = this.userid;
		userValue.fullName = this.challengerEditForm.get('fullName').value;
		userValue.email = this.emailid;
		userValue.mobileNo = this.challengerEditForm.get('mobile').value;

		this.dietService.updateUser(userValue)
			.pipe(map((res: User) => {
				if (res != null && res.fullName != null) {
					console.log(res.fullName + " user updated uccessfully!");
					this.router.navigate(['manage-user']);
				}
			}))
			.pipe(catchError((error: any) => {
				if (error.status < 400 || error.status === 500) {
					console.log("saveUser exception - " + error.status + " : " + error.message);
					return Observable.throw(new Error(error.status));
				}
			}))
			.subscribe(res => console.log(res), error => console.log(error));

		this.dietService.updateChallenger(this.challenger)
			.pipe(map((res: Challenger) => {
				if (res != null && res.fullName != null) {
					console.log(res.fullName + " challenger updated uccessfully!");
				}
			}))
			.pipe(catchError((error: any) => {
				if (error.status < 400 || error.status === 500) {
					return Observable.throw(new Error(error.status));
				}
			}))
			.subscribe(res => console.log(res), error => console.log(error));
	}

}
