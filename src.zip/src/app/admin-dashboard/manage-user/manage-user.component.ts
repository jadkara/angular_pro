import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Batch } from 'src/app/models/batch';
import { Challenger } from 'src/app/models/challenger';
import { GroupEntity } from 'src/app/models/group';
import { User } from 'src/app/models/user';
import { DietManagementService } from 'src/app/services/diet-management.service';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})
export class ManageUserComponent implements OnInit {

  displayedColumns = ['action', 'id', 'name', 'email', 'mobileNo', 'referralCode', 'batchId', 'groupId', 'userType', 'update'];
  displayedUserColumns = ['fullName', 'age', 'gender', 'state', 'country', 'bmi', 'reason', 'medicalCondition', 'dietRestriction',
    'dietType', 'pregnancyStatus', 'referredCode'];

  users: User[] = [];
  batches: Batch[] = [];
  groups: GroupEntity[] = [];
  challengers: Challenger[] = [];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatTableDataSource, { static: true }) dataSource: MatTableDataSource<User> | null;
  @ViewChild(MatTableDataSource, { static: true }) dataSourceUser: MatTableDataSource<Challenger> | null;
  clicked: boolean = false;

  constructor(private dietService: DietManagementService, private router: Router) {
    this.loadAllUsers();
    this.loadAllBatches();
    this.loadSelectedBatchGroups('1');
  }

  userTypes: any = [
    {
      role: "ADMIN"
    },
    {
      role: "MOTIVATOR"
    }
    ,
    {
      role: "CHALLENGER"
    }
  ];

  loadAllUsers() {
    this.dietService.getNonadminUsers().subscribe((data: User[]) => {
      if (data === null) {
        console.log("No users loaded!");
      } else {
        console.log("Users loaded Successfully " + data);
        this.initializeData(data);
      }
    }, error => console.log(error));
  }

  loadAllBatches() {
    this.dietService.getBatches().subscribe((data: Batch[]) => {
      if (data === null) {
        console.log("No Batch loaded!");
      } else {
        console.log("Batches loaded Successfully " + data);
        this.batches = data;
      }
    }, error => console.log(error));
  }

  loadSelectedBatchGroups(batchId: String) {
    console.log('batchId=' + batchId);
    this.dietService.getGroupsByBatch(batchId).subscribe((data: GroupEntity[]) => {
      if (data === null) {
        console.log("No Group loaded!");
      } else {
        console.log("Groups loaded Successfully " + data);
        this.groups = data;
      }
    }, error => console.log(error));
  }

  initializeData(data: User[]) {
    this.users = data;
    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(this.users);
    /**
     * Set the paginator and sort after the view init since this component will
     * be able to query its view for the initialized paginator and sort.
     */
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  showUserDetails(user: User) {
    this.clicked = !(this.clicked);
    this.dataSourceUser = null;
    this.challengers = [];
    if (this.clicked) {
      this.dietService.getChallengerByEmail(user.email)
        .pipe(map((res: Challenger) => {
          if (res != null) {
            this.challengers.push(res);
            this.dataSourceUser = new MatTableDataSource(this.challengers);
            console.log("user " + res.fullName + " details loaded by getChallengerByEmail!");
          }
        }))
        .pipe(catchError((error: any) => {
          if (error.status < 400 || error.status === 500) {
            return Observable.throw(new Error(error.status));
          }
        }))
        .subscribe(data => console.log(data), error => console.log(error));
    }
  }
  updateUser(user: User) {
    console.log("batchId=" + user.batchId);
    console.log("groupId=" + user.groupId);
    this.dietService.updateUser(user)
      .pipe(map((res: User) => {
        if (res != null) {
          console.log("user " + res.fullName + " updated successfully!");
          console.log("user batchId " + res.batchId + " updated successfully!");
          console.log("user groupId " + res.groupId + " updated successfully!");
        }
      }))
      .pipe(catchError((error: any) => {
        if (error.status < 400 || error.status === 500) {
          return Observable.throw(new Error(error.status));
        }
      }))
      .subscribe(data => console.log(data), error => console.log(error));
  }

  editUser(user: User) {
    console.log("user : " + user.fullName + " going to edit!");
    this.router.navigate(['update-challenger-info', user.email, user.id]);
  }

  deleteUser(user: User) {
    console.log("user : " + user.fullName + " going to delete!");
    this.dietService.deleteUser(user)
      .subscribe(data => console.log(data), error => console.log(error));
  }

  ngOnInit(): void {
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

}
