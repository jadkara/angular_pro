export class Batch {	
    batchId:String;
	batchName:String;
	startDate:Date;
	endDate:Date;
	measurmentDate:Date;
}
