export class User {	
    id:String;
	password:String;
	fullName: String;
	mobileNo: String;
	email: String;
	userType: String;
	referralCode: String;
	groupId: String;
	batchId: String;
}