export class DietPlan {
    batchId:String;
    fileName:string;
    dietPlanDetails:Blob;
}