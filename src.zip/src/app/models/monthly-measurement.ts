export class MonthlyMeasurement {
	userId: String;
	date : String;
	weight: number;
	height:number;
	chest:number;
	waist:number;
	shoulders:number;
	biceps:number;
	forearm:number;  
	legs:number;
	thighs:number;
}