export class GroupEntity {	
    groupId:String;
	groupName:String;;
    batchId:String;
}