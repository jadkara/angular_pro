export class DailyLog {
	userId: String;
	activityDate: Date;
	breakfast: String;
	lunch: String;
	dinner: String;
	fruits: String;
	vegetables: String;
	workouts: String;
}
