import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { User } from '../models/user';
import { AuthenticationService } from '../services/authentication.service';
import { DietManagementService } from '../services/diet-management.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  currentUser: User;
  currentUserSubscription: Subscription;
  users: User[] = [];
  registerForm: FormGroup;
  submitted = false;
  loading = false;
  currentPasswordWrong = false;
  constructor(
    private formBuilder: FormBuilder,
    private dietService: DietManagementService,
    private authenticationService: AuthenticationService,
    private userService: UserService
  ) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
      this.currentUser = user;
    });

    console.log("Constructor this.currentUser=" + this.currentUser.fullName);
    console.log("Constructor this.authenticationService.getloggeduser=" + this.authenticationService.loggedUser.fullName);
  }
  resetPassword() {
    console.log("reset password")
  }

  get f() { return this.registerForm.controls; }

  ngOnInit() {

    this.registerForm = this.formBuilder.group({
      userName: ['', Validators.required],
      currentPassword: ['', [Validators.required, Validators.minLength(8)]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
    this.loadAllUsers();
    console.log("ngOnInit this.currentUser=" + this.currentUser.fullName);
    console.log("ngOnInit this.authenticationService.getloggeduser=" + this.authenticationService.loggedUser.fullName);
  }
  onSubmit() {
    this.submitted = true;
    console.log("this.currentUser.email=" + this.currentUser.email);
    console.log("this.f.currentPassword.value=" + this.f.currentPassword.value);
    this.dietService.login(this.currentUser.email, this.f.currentPassword.value).subscribe((data: User) => {
      if (data === null) {
        console.log("Invalid credentials!");
        this.currentPasswordWrong = true;

      } else {
        console.log(data.id + " Current Password is correct ");
        this.updateUser(data);

      }
    }, error => {
      console.error(error);
    });
  }

  updateUser(user: User) {
    user.password = this.f.password.value;
    this.dietService.updateUser(user).subscribe((data: User) => {
      if (data === null) {
        console.log("Error occured !");
      } else {
        console.log("Password saved successfully ");
      }
    }, error => {
      console.error(error);
    });

  }

  change() {
    this.currentPasswordWrong = false;
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.currentUserSubscription.unsubscribe();
  }

  deleteUser(id: number) {
    this.userService.delete(id).pipe(first()).subscribe(() => {
      this.loadAllUsers()
    });
  }

  private loadAllUsers() {
    this.userService.getAll().pipe(first()).subscribe(users => {
      this.users = users;
    });
  }
}
